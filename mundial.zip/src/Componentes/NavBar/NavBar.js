import { Link } from "react-router-dom";
import "./NavBar.css";
import Home from "../Home/Home.js";
import Obtenidas from "../Figuritas/Obtenidas.js";
import Favoritas from "../Figuritas/Favoritas.js";

export default function NavBar() {
  return (
    <nav className="navegacion navbar navbar-expand-lg navbar-light navbar-custom shadow-sm">
      <div className="container-fluid">
        <h1 className="text-black brand-title">FIFA 2026</h1>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNavDropdown">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link active" to="/">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/obtenidas">
                Obtenidas
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/favoritas">
                Favoritas
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/estadisticas">
                Estadisticas
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
