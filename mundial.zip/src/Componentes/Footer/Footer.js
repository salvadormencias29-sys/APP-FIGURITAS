import "./Footert.css";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer
      className="w-100 py-4 text-white"
      style={{ backgroundColor: "#100523" }}
    >
      <div className="container">
        <div className="row">
          <div className="col-12 text-center">
            <div className="d-flex justify-content-center align-items-center gap-3 mb-2">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="btn btn-outline-light rounded-circle"
                style={{
                  width: "40px",
                  height: "40px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <i className="fab fa-facebook-f"></i>
              </a>

              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                className="btn btn-outline-light rounded-circle"
                style={{
                  width: "40px",
                  height: "40px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <i className="fab fa-twitter"></i>
              </a>

              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="btn btn-outline-light rounded-circle"
                style={{
                  width: "40px",
                  height: "40px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <i className="fab fa-instagram"></i>
              </a>

              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="btn btn-outline-light rounded-circle"
                style={{
                  width: "40px",
                  height: "40px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <i className="fab fa-youtube"></i>
              </a>
            </div>

            {/* Línea divisoria */}
            <hr
              className=""
              style={{
                borderColor: "rgba(255,255,255,0.1)",
                maxWidth: "400px",
                margin: "0 auto",
              }}
            />

            {/* Texto de Copyright */}
            <p className="mb-0 text-white">
              © 2026 Álbum Virtual FIFA. Este sitio es para fines educativos y
              de entretenimiento.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
