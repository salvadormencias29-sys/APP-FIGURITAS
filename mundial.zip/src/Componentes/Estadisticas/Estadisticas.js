import React, { useState, useEffect } from "react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from "recharts";

import colombiaImg from "../Imagenes/Colombia.png";
import brasilImg from "../Imagenes/Brasil.png";
import argentinaImg from "../Imagenes/Argentina.png";
import franciaImg from "../Imagenes/Francia.png";
import portugalImg from "../Imagenes/Portugal.png";
import españaImg from "../Imagenes/España.png";
import alemaniaImg from "../Imagenes/Alemania.png";

const selecciones = [
  { nombre: "Colombia", img: colombiaImg },
  { nombre: "Brasil", img: brasilImg },
  { nombre: "Argentina", img: argentinaImg },
  { nombre: "Francia", img: franciaImg },
  { nombre: "Portugal", img: portugalImg },
  { nombre: "España", img: españaImg },
  { nombre: "Alemania", img: alemaniaImg },
];

const TOPE_POR_SELECCION = 18;
const TOTAL_ALBUM = 126;
const COLORES = [
  "#3163aa",
  "#114f34",
  "#000000",
  "#FFFFFF",
  "#FF0000",
  "#FFCC00",
  "#79303e",
  "#e0e0e0",
];

export default function Estadisticas() {
  const [datosGrafico, setDatosGrafico] = useState([]);
  const [datosTarjetas, setDatosTarjetas] = useState([]);

  useEffect(() => {
    const guardadas = JSON.parse(localStorage.getItem("misFiguritas")) || [];
    let totalObtenidas = 0;

    const calculo = selecciones.map((sel) => {
      const cantidad = guardadas.filter(
        (f) => f.nacionalidad === sel.nombre
      ).length;
      totalObtenidas += cantidad;
      return {
        name: sel.nombre,
        value: cantidad,
        porcentaje: (cantidad / TOPE_POR_SELECCION) * 100,
      };
    });

    const faltantes = TOTAL_ALBUM - totalObtenidas;

    setDatosTarjetas(calculo);
    setDatosGrafico([...calculo, { name: "Faltantes", value: faltantes }]);
  }, []);

  return (
    <div className="container py-5">
      <h1 className="text-center mb-5">ESTADÍSTICAS DEL ÁLBUM</h1>

      <div className="card p-4 mb-5 shadow-sm" style={{ height: "400px" }}>
        <h4 className="text-center">
          Progreso Total (Total: {TOTAL_ALBUM} figuritas)
        </h4>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={datosGrafico}
              dataKey="value"
              nameKey="name"
              outerRadius={100}
              label
            >
              {datosGrafico.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORES[index % COLORES.length]}
                />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="row g-4">
        {datosTarjetas.map((item, index) => (
          <div className="col-md-4" key={item.name}>
            <div
              className="card h-100 p-3 shadow-sm border-left"
              style={{ borderLeft: `5px solid ${COLORES[index]}` }}
            >
              <h3>{item.name}</h3>
              <div className="progress mb-2" style={{ height: "20px" }}>
                <div
                  className="progress-bar"
                  style={{
                    width: `${item.porcentaje}%`,
                    backgroundColor: COLORES[index],
                  }}
                >
                  {Math.round(item.porcentaje)}%
                </div>
              </div>
              <small>
                {item.value} de {TOPE_POR_SELECCION} figuritas
              </small>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
