import { useState, useEffect } from "react";
import "./Obtenidas.css";
import colombiaImg from "../Imagenes/Colombia.png";
import brasilImg from "../Imagenes/Brasil.png";
import argentinaImg from "../Imagenes/Argentina.png";
import franciaImg from "../Imagenes/Francia.png";
import portugalImg from "../Imagenes/Portugal.png";
import españaImg from "../Imagenes/España.png";
import alemaniaImg from "../Imagenes/Alemania.png";

const configuracionEquipos = {
  Brasil: {
    imagen: brasilImg,
    color: "#114f34",
    fuente: "Nova Square, sans-serif",
  },
  Colombia: {
    imagen: colombiaImg,
    color: "#3163aa",
    fuente: "Righteous, sans-serif",
  },
  Argentina: {
    imagen: argentinaImg,
    color: "black",
    fuente: "Audiowide, sans-serif",
  },
  Francia: { imagen: franciaImg, color: "white", fuente: "Anta, sans-serif" },
  Portugal: {
    imagen: portugalImg,
    color: "white",
    fuente: "Combo, sans-serif",
  },
  Alemania: {
    imagen: alemaniaImg,
    color: "black",
    fuente: "ZCOOL QingKe HuangYou, sans-serif",
  },
  España: {
    imagen: españaImg,
    color: "#79303e",
    fuente: "Electrolize, sans-serif",
  },
};

const POSICIONES = [
  "POR",
  "CT",
  "LD",
  "LI",
  "MC",
  "MCD",
  "MCO",
  "EI",
  "DC",
  "ED",
  "MP",
  "II",
  "ID",
];
const TOPE_POR_SELECCION = 18;

export default function Obtenidas() {
  const [figuritas, setFiguritas] = useState(() => {
    const guardadas = localStorage.getItem("misFiguritas");
    return guardadas ? JSON.parse(guardadas) : [];
  });

  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [datosForm, setDatosForm] = useState({
    nombre: "",
    posicion: "",
    nacionalidad: "",
    club: "",
    numero: "",
  });

  const [filtroNacionalidad, setFiltroNacionalidad] = useState("");
  const [filtroPosicion, setFiltroPosicion] = useState("");

  useEffect(() => {
    localStorage.setItem("misFiguritas", JSON.stringify(figuritas));
  }, [figuritas]);

  const manejarCambio = (e) =>
    setDatosForm({ ...datosForm, [e.target.name]: e.target.value });

  const agregarJugador = () => {
    if (
      datosForm.nombre === "" ||
      datosForm.nacionalidad === "" ||
      datosForm.posicion === ""
    ) {
      alert("Por favor, completa todos los campos.");
      return;
    }
    const cantidadActual = figuritas.filter(
      (f) => f.nacionalidad === datosForm.nacionalidad
    ).length;

    if (cantidadActual >= TOPE_POR_SELECCION) {
      alert("Selección completa, quita jugadores para añadir más");
      return;
    }

    setFiguritas([
      ...figuritas,
      { ...datosForm, id: Date.now(), esFavorito: false },
    ]);
    setDatosForm({
      nombre: "",
      posicion: "",
      nacionalidad: "",
      club: "",
      numero: "",
    });
    setMostrarFormulario(false);
  };

  const toggleFavorito = (id) => {
    setFiguritas(
      figuritas.map((fig) =>
        fig.id === id ? { ...fig, esFavorito: !fig.esFavorito } : fig
      )
    );
  };

  const figuritasFiltradas = figuritas.filter((fig) => {
    const coincideNacionalidad =
      filtroNacionalidad === "" || fig.nacionalidad === filtroNacionalidad;
    const coincidePosicion =
      filtroPosicion === "" || fig.posicion === filtroPosicion;
    return coincideNacionalidad && coincidePosicion;
  });

  return (
    <div className="container py-5">
      <div className="text-center mb-5">
        <h1>FIGURITAS OBTENIDAS</h1>
        <button
          className="btn btn-primary mt-3"
          onClick={() => setMostrarFormulario(true)}
        >
          + Agregar Nuevo Jugador
        </button>
      </div>

      {mostrarFormulario && (
        <div
          className="card p-4 mb-5 shadow mx-auto"
          style={{ maxWidth: "500px" }}
        >
          <h5>Datos del Jugador</h5>
          <input
            name="nombre"
            placeholder="Nombre"
            className="form-control mb-2"
            onChange={manejarCambio}
            value={datosForm.nombre}
          />
          <select
            name="posicion"
            className="form-select mb-2"
            onChange={manejarCambio}
            value={datosForm.posicion}
          >
            <option value="">Selecciona Posición</option>
            {POSICIONES.map((pos) => (
              <option key={pos} value={pos}>
                {pos}
              </option>
            ))}
          </select>
          <input
            name="numero"
            placeholder="Número"
            className="form-control mb-2"
            onChange={manejarCambio}
            value={datosForm.numero}
          />
          <select
            name="nacionalidad"
            className="form-select mb-2"
            onChange={manejarCambio}
            value={datosForm.nacionalidad}
          >
            <option value="">Selecciona Nacionalidad</option>
            {Object.keys(configuracionEquipos).map((pais) => (
              <option key={pais} value={pais}>
                {pais}
              </option>
            ))}
          </select>
          <input
            name="club"
            placeholder="Club"
            className="form-control mb-3"
            onChange={manejarCambio}
            value={datosForm.club}
          />
          <button className="btn btn-success" onClick={agregarJugador}>
            Añadir
          </button>
        </div>
      )}

      <div className="card p-3 mb-4 bg-light">
        <h5>Filtrar lista:</h5>
        <div className="row g-2">
          <div className="col-md-6">
            <select
              className="form-select"
              onChange={(e) => setFiltroNacionalidad(e.target.value)}
            >
              <option value="">Todas las nacionalidades</option>
              {Object.keys(configuracionEquipos).map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
          <div className="col-md-6">
            <select
              className="form-select"
              onChange={(e) => setFiltroPosicion(e.target.value)}
            >
              <option value="">Todas las posiciones</option>
              {POSICIONES.map((pos) => (
                <option key={pos} value={pos}>
                  {pos}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="row g-4">
        {figuritasFiltradas.map((fig) => {
          const config = configuracionEquipos[fig.nacionalidad] || {
            imagen: colombiaImg,
            color: "black",
            fuente: "sans-serif",
          };
          return (
            <div className="col-md-4" key={fig.id}>
              <div className="card h-100 p-3 position-relative">
                <div
                  onClick={() => toggleFavorito(fig.id)}
                  style={{
                    cursor: "pointer",
                    position: "absolute",
                    top: "10px",
                    right: "10px",
                    fontSize: "1.5rem",
                    color: fig.esFavorito ? "#ffc107" : "#ccc",
                    zIndex: 10,
                  }}
                >
                  <i
                    className={fig.esFavorito ? "fas fa-star" : "far fa-star"}
                  ></i>
                </div>
                <div className="contenedor-camiseta">
                  <img
                    src={config.imagen}
                    style={{ width: "200px", height: "auto" }}
                    alt="Camiseta"
                  />
                  <div
                    style={{
                      position: "absolute",
                      top: "15%",
                      width: "100%",
                      color: config.color,
                      fontFamily: config.fuente,
                      textAlign: "center",
                    }}
                  >
                    <div
                      style={{
                        fontSize: "1rem",
                        fontWeight: "bold",
                        textTransform: "uppercase",
                      }}
                    >
                      {fig.nombre}
                    </div>
                    <div style={{ fontSize: "4rem", fontWeight: "900" }}>
                      {fig.numero}
                    </div>
                  </div>
                </div>
                <div className="card-body text-center">
                  <h5>{fig.nombre}</h5>
                  <p>
                    {fig.posicion} - {fig.nacionalidad}
                  </p>
                  <small className="text-muted">Club: {fig.club}</small>
                  <br />
                  <button
                    className="btn btn-danger btn-sm mt-3"
                    onClick={() =>
                      setFiguritas(figuritas.filter((f) => f.id !== fig.id))
                    }
                  >
                    Borrar
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
