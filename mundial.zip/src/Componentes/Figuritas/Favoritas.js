import { useState, useEffect } from "react";
import "./Obtenidas.css";
import colombiaImg from "../Imagenes/Colombia.png";
import brasilImg from "../Imagenes/Brasil.png";
import argentinaImg from "../Imagenes/Argentina.png";
import franciaImg from "../Imagenes/Francia.png";
import portugalImg from "../Imagenes/Portugal.png";
import españaImg from "../Imagenes/España.png";
import alemaniaImg from "../Imagenes/Alemania.png";

const configuracionEquipos = {
  Brasil: {
    imagen: brasilImg,
    color: "#114f34",
    fuente: "Nova Square, sans-serif",
  },
  Colombia: {
    imagen: colombiaImg,
    color: "#3163aa",
    fuente: "Righteous, sans-serif",
  },
  Argentina: {
    imagen: argentinaImg,
    color: "black",
    fuente: "Audiowide, sans-serif",
  },
  Francia: { imagen: franciaImg, color: "white", fuente: "Anta, sans-serif" },
  Portugal: {
    imagen: portugalImg,
    color: "white",
    fuente: "Combo, sans-serif",
  },
  Alemania: {
    imagen: alemaniaImg,
    color: "black",
    fuente: "ZCOOL QingKe HuangYou, sans-serif",
  },
  España: {
    imagen: españaImg,
    color: "#79303e",
    fuente: "Electrolize, sans-serif",
  },
};

export default function Favoritas() {
  const toggleFavorito = (id) => {
    const guardadas = JSON.parse(localStorage.getItem("misFiguritas")) || [];

    const actualizadas = guardadas.map((fig) =>
      fig.id === id ? { ...fig, esFavorito: !fig.esFavorito } : fig
    );

    localStorage.setItem("misFiguritas", JSON.stringify(actualizadas));

    setFavoritas(actualizadas.filter((fig) => fig.esFavorito));
  };
  const [favoritas, setFavoritas] = useState([]);

  useEffect(() => {
    const todas = JSON.parse(localStorage.getItem("misFiguritas")) || [];
    setFavoritas(todas.filter((fig) => fig.esFavorito));
  }, []);

  return (
    <div className="container py-5">
      <h1 className="text-center mb-5">FIGURITAS FAVORITAS</h1>
      <div className="row g-4">
        {favoritas.length > 0 ? (
          favoritas.map((fig) => {
            const config = configuracionEquipos[fig.nacionalidad] || {
              imagen: colombiaImg,
              color: "black",
              fuente: "sans-serif",
            };

            return (
              <div className="col-md-4" key={fig.id}>
                <div className="card h-100 p-3 position-relative">
                  <div
                    onClick={() => toggleFavorito(fig.id)}
                    style={{
                      cursor: "pointer",
                      position: "absolute",
                      top: "10px",
                      right: "10px",
                      fontSize: "1.5rem",
                      color: fig.esFavorito ? "#ffc107" : "#ccc",
                    }}
                  >
                    <i
                      className={fig.esFavorito ? "fas fa-star" : "far fa-star"}
                    ></i>
                  </div>
                  <div className="contenedor-camiseta">
                    <img
                      src={config.imagen}
                      style={{ width: "200px", height: "auto" }}
                      alt="Camiseta"
                    />
                    <div
                      style={{
                        position: "absolute",
                        top: "15%",
                        width: "100%",
                        color: config.color,
                        fontFamily: config.fuente,
                        textAlign: "center",
                      }}
                    >
                      <div
                        style={{
                          fontSize: "1rem",
                          fontWeight: "bold",
                          textTransform: "uppercase",
                        }}
                      >
                        {fig.nombre}
                      </div>
                      <div style={{ fontSize: "4rem", fontWeight: "900" }}>
                        {fig.numero}
                      </div>
                    </div>
                  </div>
                  <div className="card-body text-center">
                    <h5>{fig.nombre}</h5>
                    <p>
                      {fig.posicion} - {fig.nacionalidad}
                    </p>
                    <small className="text-muted">Club: {fig.club}</small>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <p className="text-center">
            No has marcado ninguna figurita como favorita.
          </p>
        )}
      </div>
    </div>
  );
}
