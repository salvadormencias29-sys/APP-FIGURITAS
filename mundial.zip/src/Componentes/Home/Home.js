import "./Home.css";
import { Link } from "react-router-dom";
import Obtenidas from "../Figuritas/Obtenidas.js";

export default function Home() {
  return (
    <div>
      <div className="banner">
        <div className="cont text-center w-50">
          <h1 className="text-white">COPA MUNDIAL</h1>
          <h1 className="text-white">DE LA FIFA 2026</h1>
          <h3 className="text-white">11 DE JUNIO - 19 DE JULIO</h3>
        </div>
      </div>

      <div className="banderas">
        <div className="canada">
          <div className="info-pais">
            <h2>Canadá</h2>
            <p>Sede: Toronto / Vancouver</p>
          </div>
        </div>
        <div className="mexico">
          <div className="info-pais">
            <h2>México</h2>
            <p>Estadio Azteca / Monterrey / Guadalajara</p>
          </div>
        </div>
        <div className="eeuu">
          <div className="info-pais">
            <h2>EE. UU.</h2>
            <p>Gran Final / Múltiples sedes</p>
          </div>
        </div>
      </div>
      <div className="seccion-coleccion">
        <h1 className="titulo-coleccion">COLECCIÓN</h1>

        <div className="bloques-coleccion">
          <Link className="bloque-item obtenidas" to="/obtenidas">
            <div className="contenido-bloque">
              <i className="fas fa-check-circle icono-bloque"></i>
              <h2>Obtenidas</h2>
              <p>Revisa tus figuritas guardadas</p>
            </div>
          </Link>
          <Link className="bloque-item favoritas" to="/favoritas">
            <div className="contenido-bloque">
              <i className="fas fa-star icono-bloque"></i>
              <h2>Favoritas</h2>
              <p>Tus jugadores destacados</p>
            </div>
          </Link>
          <Link className="bloque-item faltantes" to="/estadisticas">
            <div className="contenido-bloque">
              <i className="fas fa-exclamation-circle icono-bloque"></i>
              <h2>Estadísticas</h2>
              <p>Mira aqui las estadisticas de las figuritas</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
