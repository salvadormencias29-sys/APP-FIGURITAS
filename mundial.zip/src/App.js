import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./styles.css";
import NavBar from "./Componentes/NavBar/NavBar.js";
import Home from "./Componentes/Home/Home.js";
import Footer from "./Componentes/Footer/Footer.js";
import Obtenidas from "./Componentes/Figuritas/Obtenidas.js";
import Favoritas from "./Componentes/Figuritas/Favoritas.js";
import Estadisticas from "./Componentes/Estadisticas/Estadisticas.js";

export default function App() {
  return (
    <div>
      <BrowserRouter>
        <NavBar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/obtenidas" element={<Obtenidas />} />
          <Route path="/favoritas" element={<Favoritas />} />
          <Route path="/estadisticas" element={<Estadisticas />} />
        </Routes>
      </BrowserRouter>
      <Footer />
    </div>
  );
}
